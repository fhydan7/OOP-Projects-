﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleMenu
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
            void menu()
            {
                Console.Clear();

                
                Console.WriteLine("1. About Me");
                Console.WriteLine("2. Close.");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": Developer(); break;
                    case "2": Close(); break;

                }
            }

            void Developer()
            {
                Console.WriteLine("This is Fahad Dahish, I'm from Sauid Arabia. i enjoy playing video games. I wish i can become video games hacker.");
                Console.ReadKey();
                menu();

            }
            void Close()
            {
                Environment.Exit(0);
            }
        }
    }
}
