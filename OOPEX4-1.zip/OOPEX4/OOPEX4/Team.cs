﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX4
{
    class Team
    {

        public Team(string teamname, string cityname, List<Player> players)
        {
            this.TeamName = teamname;
            this.CityName = cityname;
            this.Players = players;
        }

        public string TeamName { get; set; }
        public string CityName { get; set; }
        public List<Player> Players { get; set; }
    }
}
