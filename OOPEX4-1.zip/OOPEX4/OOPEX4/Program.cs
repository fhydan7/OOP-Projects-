﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX4
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Player> players = new List<Player>();


            players.Add(new Player("Sean McVay", "Coach", 50 ));
            players.Add(new Player("Jared Goff", "Queaterback", 26 ));
            players.Add(new Player("Todd Gurley","Running Back", 27 ));
            players.Add(new Player("John Kelly", "Running Back",22 ));
            players.Add(new Player("Cooper Kupp", "Wide Receivers", 21 ));
            players.Add(new Player("Nsimba Webster", "Wide Receivers",24 ));
            players.Add(new Player("Johnny Mundt", "Tight End", 26 ));
            players.Add(new Player("Troy Hill",  "Corner Backs", 22 ));
            players.Add(new Player("Jalen Ramsey", "Corner Backs", 20 ));
            players.Add(new Player("John Johnson", "Safeties" ,25 ));
            players.Add(new Player("Marqui Christian", "Safeties", 26 ));
            players.Add(new Player("Aaron Donald", "Defensive Tackle", 29 ));
            players.Add(new Player("Morgan Fox", "Defensive End", 28 ));
            players.Add(new Player("Justin Lawler", "Line Backer", 30));
            players.Add(new Player("Greg Zuerlein", "Kicker", 31));


            Team LosAngelesRams = new Team("Los Angeles Rams, ", "Los Angeles area: ", players);

            Console.WriteLine(LosAngelesRams.TeamName + " " + LosAngelesRams.CityName);


            foreach (Player x in LosAngelesRams.Players)
            {
                Console.WriteLine(x.Name + " " + x.Spot + " " + x.Age);

            }

            Console.ReadKey();

        }
    }
    }
