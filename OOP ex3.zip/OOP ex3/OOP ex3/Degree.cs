﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_ex3
{
    class Degree
    {
        public Degree(PassFailCourse courseA, PassFailCourse courseB, GradedCourse gradedA, GradedCourse gradedB)
        {
            this.PFCourseA = courseA;
            this.PFCourseB = courseB;
            this.GCourseA = gradedA;
            this.GCourseB = gradedB;
        }

        public PassFailCourse PFCourseA { get; set; }
        public PassFailCourse PFCourseB { get; set; }
        public GradedCourse GCourseA { get; set; }
        public GradedCourse GCourseB { get; set; }


        public bool Passed()
        {
            int count = 0;
            if (PFCourseA.Passed() == true)
            {
                count++;
            }
            if (PFCourseB.Passed() == true)
            {
                count++;
            }
            if (GCourseA.Passed() == true)
            {
                count++;
            }
            if (GCourseB.Passed() == true)
            {
                count++;
            }
            if (count >= 3)
            {
                return true;

            }
            else
            {
                return false;

            }
        }
    }
}
