﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_ex3
{
    class PassFailCourse
    {


        public PassFailCourse(bool grade, string coursename)
        {

            this.Grade = grade;
            this.Coursename = coursename;

        }

        public string Coursename { get; set; }
        public bool Grade { get; set; }

        public bool Passed()
        {
            return this.Grade;
        }

    }
}
