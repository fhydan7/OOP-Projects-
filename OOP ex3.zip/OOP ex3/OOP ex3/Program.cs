﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_ex3
{
    class Program
    {
        static void Main(string[] args)
        {

            PassFailCourse math = new PassFailCourse(true, "Mathematics");
            PassFailCourse Geo = new PassFailCourse(false, "Geology");

            GradedCourse Science = new GradedCourse(90.5m, "Science");
            GradedCourse Computer = new GradedCourse(77.9m, "Computer");


            Degree LiberalArts = new Degree(math, Geo, Science, Computer);

            if (LiberalArts.Passed() == true)
            {
                Console.WriteLine("You passed!");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Please Try again ");
                Console.ReadKey();

            }
            


            Console.ReadKey();

        }
    }
}
