﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_ex3
{
    class GradedCourse
    {
        public GradedCourse(decimal grade, string coursename)
        {
            this.Coursename = coursename;
            this.Grade = grade;

        }

        public string Coursename { get; set; }
        public decimal Grade { get; set; }

        public bool Passed()
        {
            if (Grade >= 70)
            {

                return true;

            }
            else
            {
                return false;

            }
        }

    }
}

