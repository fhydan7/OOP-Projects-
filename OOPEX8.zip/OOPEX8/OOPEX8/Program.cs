﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX8
{
    class Program
    {
        static void Main(string[] args)
        {


            CheckingAccount one = new CheckingAccount(1234, 19060);
            SavingsAccount two = new SavingsAccount(4321, 50000);
            SavingsAccount three = new SavingsAccount(4321, 70500);
            CheckingAccount four = new CheckingAccount(4321, 28000);
            SavingsAccount five = new SavingsAccount(4321, 90000);

            List<CheckingAccount> Listone = new List<CheckingAccount>() { one, four };
            List<SavingsAccount> Listtwo = new List<SavingsAccount>() { two, three, five };

            Members Fahad = new Members("Fahad Dahish ", 1788, Listone, Listtwo);
            Members Moe = new Members("Moe Minshad ", 1699, Listone, Listtwo);

            List<Members> AllMembers = new List<Members>() { Fahad, Moe };

            Bank ChaseBank = new Bank(AllMembers, 1000000);

            Console.WriteLine("ChaseBank");
            Console.WriteLine("List of all Members: "); ChaseBank.ListAllMembers();
            ChaseBank.GetTransactionCount();
            Console.WriteLine("_________________________________________");

            Console.WriteLine("Account one ");
            one.CheckBalance();
            one.GetTransactionCount();



            Console.WriteLine("Deposit money in your account: ");
            decimal deposit = decimal.Parse(Console.ReadLine());

            one.AddFunds(deposit);
            Console.WriteLine("_________________________________________");
            one.CheckBalance();
            one.GetTransactionCount();





            Console.ReadKey();
        }
    }
}
