﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX8
{
    class Members
    {
        public string Name { get; set; }
        public int MemberID { get; set; }
        public List<CheckingAccount> Checkings { get; set; }
        public List<SavingsAccount> Savings { get; set; }

        public Members(string name, int memberid, List<CheckingAccount> checking, List<SavingsAccount> savings)
        {
            this.Name = name;
            this.MemberID = memberid;
            this.Savings = savings;
            this.Checkings = checking;
        }

        // Modify it and move to accounts
        public int GetTransactionCount(int X, int Y)
        {
            int Total = 0;
            foreach (SavingsAccount Z in Savings)
            {
                Total += Z.GetTransaction();
                Console.WriteLine("Savings Transaction Count: ");

            }
            foreach (CheckingAccount Z in Checkings)
            {
                Total += Z.GetTransaction();
                Console.WriteLine("Checking Transaction Count: ");
            }
            Console.WriteLine("Total transaction Count: " + Total);

            return X + Y;

        }



    }
}
