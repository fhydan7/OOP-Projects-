﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX8
{
    class SavingsAccount : Accounts
    {
        public SavingsAccount(int accountid, int balance) : base(accountid, balance)
        {


        }


    }
}