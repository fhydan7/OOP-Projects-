﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX8
{
    class Bank
    {
        public List<Members> Members { get; set; }
        public int Balance { get; set; }

        public Bank(List<Members> members, int balance)
        {
            this.Members = members;
            this.Balance = balance;
        }

        public void ListAllMembers()
        {
            foreach (Members x in Members)
            {
                Console.WriteLine(x.Name + x.MemberID);
            }

        }
        public void GetTransactionCount()
        {
            int Checkingscount = 0;
            int Savingscount = 0;

            foreach (Members x in Members)
            {
                foreach (CheckingAccount y in x.Checkings)
                {
                    Checkingscount += y.GetTransaction();

                }
            }
            Console.WriteLine("Checking Transactions: " + Checkingscount);
            foreach (Members x in Members)
            {
                foreach (SavingsAccount y in x.Savings)
                {
                    Savingscount += y.GetTransaction();

                }
            }
            Console.WriteLine("Savings Transactions: " + Savingscount);

        }
        public void GetAccountTypeCount()
        {
            int Checking = 0;
            int Savings = 0;

            foreach (Members x in Members)
            {
                foreach (CheckingAccount y in x.Checkings)
                {

                    Checking++;
                }
                foreach (SavingsAccount z in x.Savings)
                {

                    Savings++;
                }

            }
            Console.WriteLine("Number of Checking: " + Checking);
            Console.WriteLine("Number of Savings: " + Savings);


        }


    }


}
