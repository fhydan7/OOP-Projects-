﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX8
{
    class CheckingAccount : Accounts
    {

        public CheckingAccount(int accountid, int balance) : base(accountid, balance)
        {



        }

    }
}