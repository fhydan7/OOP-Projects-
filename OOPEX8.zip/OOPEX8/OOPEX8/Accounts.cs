﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX8
{
    class Accounts
    {

        /*
         Account are the most important aspect of our bank. By making the private it will strenghthen
         the structure of our bank by avoiding future changes made by people who are not allowed.
            The following properties should not be accesible to the general public or account holder.
         Account Name, account ID, Balance of the account, Closing an account and getting the count
         of accounts should only be accesible by administrators.
        */

        private int AccountID { get; set; }
        private decimal Balance { get; set; }
        private bool Closed { get; set; }

        private int TransactionCount { get; set; }

        public Accounts(int accountid, int balance)
        {

            this.AccountID = accountid;
            this.Balance = balance;
            this.Closed = false;
            this.TransactionCount = 0;
        }

        public void CloseAccount()
        {
            this.Closed = true;

        }
        public void AddFunds(decimal deposit)
        {

            Console.WriteLine("Amount added: " + deposit);



            if (deposit > 0)
            {
                Balance = Balance + deposit;
                TransactionCount++;
            }
            else if (deposit < 0)
            {
                Console.WriteLine("You can't Add a negative value to your account");
            }
            else
            {
                Console.WriteLine("You selected 0 dollars to Add: ");
            }

        }
        public void CheckBalance()
        {

            Console.WriteLine("Account Balance: " + Balance);
        }
        public void GetTransactionCount()
        {
            Console.WriteLine("Transaction Count: " + TransactionCount);

        }
       
        public int GetTransaction()
        {
            return this.TransactionCount;

        }

    }
}

