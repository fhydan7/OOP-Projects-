﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX5OOP
{
    class Court
    {
        public Court(Location ball, Location reff, Team t1, Team t2)
        {
            this.Ball = ball;
            this.Reff = reff;
            this.T1 = t1;
            this.T2 = t2;
        }
        public Location Ball { get; set; }
        public Location Reff { get; set; }
        public Team T1 { get; set; }
        public Team T2 { get; set; }

        public void distanc()
        {
            double distance = 0;

            List<double> newdistances = new List<double>();


            distance = Math.Sqrt(Math.Pow(T1.P1.X - Reff.X, 2) + Math.Pow(T1.P1.Y - Reff.Y, 2));
            newdistances.Add(distance);
            distance = Math.Sqrt(Math.Pow(T1.P2.X - Reff.X, 2) + Math.Pow(T1.P2.Y - Reff.Y, 2));
            newdistances.Add(distance);

            distance = Math.Sqrt(Math.Pow(T1.P3.X - Reff.X, 2) + Math.Pow(T1.P3.Y - Reff.Y, 2));
            newdistances.Add(distance);

            distance = Math.Sqrt(Math.Pow(T2.P1.X - Reff.X, 2) + Math.Pow(T2.P1.Y - Reff.Y, 2));
            newdistances.Add(distance);

            distance = Math.Sqrt(Math.Pow(T2.P2.X - Reff.X, 2) + Math.Pow(T2.P2.Y - Reff.Y, 2));
            newdistances.Add(distance);

            distance = Math.Sqrt(Math.Pow(T2.P3.X - Reff.X, 2) + Math.Pow(T2.P3.Y - Reff.Y, 2));
            newdistances.Add(distance);



            newdistances.Sort();

            for (int i = 0; i < newdistances.Count(); i++)

            {

                Console.WriteLine(newdistances[i]);

            }

            Console.WriteLine("(" + Ball.X + "," + Ball.Y + ")");
            Console.WriteLine("(" + Reff.X + "," + Reff.Y + ")");


            Console.WriteLine("(" + T1.P1.X + "," + T1.P1.Y + ")");
            Console.WriteLine("(" + T1.P2.X + "," + T1.P2.Y + ")");
            Console.WriteLine("(" + T1.P3.X + "," + T1.P3.Y + ")");
            Console.WriteLine("(" + T2.P1.X + "," + T2.P1.Y + ")");
            Console.WriteLine("(" + T2.P2.X + "," + T2.P2.Y + ")");
            Console.WriteLine("(" + T2.P3.X + "," + T2.P3.Y + ")");



   



        }

        public bool Scored()
        {

            if ((Ball.X == -1 || Ball.X == 1) && ((Ball.Y >= -5 && Ball.Y <= -3) || (Ball.Y >= 3 && Ball.Y <= 5)))
            {
                return true;
            }
            else
            {
                return false;

            }


        }
    }
}
