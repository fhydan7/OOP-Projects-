﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX5OOP
{
    class Team
    {
        public Team(Location p1, Location p2, Location p3)
        {
            this.P1 = p1;
            this.P2 = p2;
            this.P3 = p3;
        }

        public Location P1 { get; set; }
        public Location P2 { get; set; }
        public Location P3 { get; set; }
    }
}
