﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX5OOP
{
    class Program
    {
        static void Main(string[] args)
        {

            Location t1p1 = new Location(2, 4);
            Location t1p2 = new Location(1, 4);
            Location t1p3 = new Location(0, 3);
            Team t1 = new Team(t1p1, t1p2, t1p3);

            Location t2p1 = new Location(-5, 4);
            Location t2p2 = new Location(1, -4);
            Location t2p3 = new Location(-3, 3);
            Team t2 = new Team(t2p1, t2p2, t2p3);
            Location reff = new Location(3 , 2);
            Location ball = new Location(-1, 3);


            Court newcourt = new Court(ball, reff, t1, t2);

            newcourt.distanc();
            newcourt.Scored();


            Console.ReadKey();

        }
    }
}
