﻿using System;

namespace SMOOP2
{

    class Program
    {
        static void Main(string[] args)
        {

            List<int> studentID = new List<int>();
            List<string> firstname = new List<string>();
            List<string> lastname = new List<string>();
            List<decimal> grade = new List<decimal>();


            MainMenu();

            void MainMenu()
            {

                Console.Clear();

                Console.WriteLine("Welcome to Student Grader");
                Console.WriteLine("Choose one of the following options");
                Console.WriteLine("1. Add Student Information");
                Console.WriteLine("2. Enter Student Grades");
                Console.WriteLine("3. Remove Student");
                Console.WriteLine("4. Grade Analytics");
                Console.WriteLine("5. Close Application");
                string usersChoice = Console.ReadLine();


                switch (usersChoice)
                {
                    case "1": addstudent(); break;
                    case "2": entergrade(); break;
                    case "3": remove(); break;
                    case "4": analytics(); break;
                    case "5": close(); break;



                }

            }

            void addstudent()
            {
                Console.Clear();
                try
                {
                    Console.WriteLine("Enter ID Number: ");
                    int ID = Convert.ToInt32(Console.ReadLine());
                    studentID.Add(ID);
                }
                catch
                {
                    Console.WriteLine("ERROR: You must Enter a Numeric Value!");
                    Console.ReadKey();

                    addstudent();
                }

                Console.WriteLine("Enter Name: ");
                string first = Console.ReadLine();
                firstname.Add(first);

                Console.WriteLine("Enter Last Name: ");
                string last = Console.ReadLine();
                lastname.Add(last);

                grade.IndexOf(studentID.Capacity);


                MainMenu();

            }
            void entergrade()
            {
                Console.Clear();

                for (int x = 0; x < studentID.Count; x++)
                {
                    Console.WriteLine("Name: " + firstname[x] + " " + lastname[x] + "|ID: " + studentID[x]);
                }


                Console.WriteLine("Enter Student ID to Add a Grade: ");
                int num = Convert.ToInt32(Console.ReadLine());
                int y = studentID.IndexOf(num);



                if (y < 0)
                {
                    Console.WriteLine("ID does not Exist");
                    entergrade();
                }
                else
                {
                    Console.WriteLine("Enter a Grade for Student: ");
                    decimal g = Convert.ToDecimal(Console.ReadLine());
                    grade.Add(g);


                }

                for (int x = 0; x < grade.Count; x++)
                {
                    grade.IndexOf(x);
                    Console.WriteLine("Name: " + firstname[x] + " " + lastname[x] + " |ID: " + studentID[x] + " |Grades: " + grade[x]);

                }

                Console.ReadKey();
                MainMenu();



            }
            void remove()
            {
                Console.Clear();

                for (int x = 0; x < studentID.Count; x++)
                {
                    Console.WriteLine("Name: " + firstname[x] + " " + lastname[x] + "|ID: " + studentID[x]);
                }


                Console.WriteLine("Enter ID to delete a student: ");
                int num = Convert.ToInt32(Console.ReadLine());
                int y = studentID.IndexOf(num);


                grade.IndexOf(num);

                studentID.RemoveAt(y);
                firstname.RemoveAt(y);
                lastname.RemoveAt(y);
                try
                {
                    grade.RemoveAt(y);

                }
                catch
                {

                }
                Console.WriteLine("New List without the Student:");

                for (int x = 0; x < studentID.Count; x++)
                {
                    Console.WriteLine("Name: " + firstname[x] + " " + lastname[x] + "|ID: " + studentID[x]);
                }

                Console.ReadKey();


                MainMenu();

            }
            void analytics()
            {

                decimal avg = 0;
                decimal min = 0;
                decimal max = 0;
                decimal acount = 0;
                decimal bcount = 0;
                decimal ccount = 0;
                decimal dcount = 0;
                decimal fcount = 0;

                foreach (decimal m in grade)
                {
                    grade.IndexOf(m);
                    if (m > 0)
                    {
                        max = grade.Max();
                    }
                    if (m > 0)
                    {
                        min = grade.Min();
                    }
                    if (m > 0)
                    {
                        avg = avg + m;
                    }

                    if (m >= 90)
                    {
                        acount = acount + 1;
                    }

                    else if (m >= 80)
                    {
                        bcount = bcount + 1;
                    }

                    else if (m >= 70)
                    {
                        ccount = ccount + 1;
                    }

                    else if (m >= 60)
                    {
                        dcount = dcount + 1;
                    }

                    else if (m < 60)
                    {
                        fcount = fcount + 1;
                    }
                    else
                    {

                    }
                }
                decimal avgresult = avg / grade.Count;
                decimal aresult = acount / grade.Count;
                decimal bresult = bcount / grade.Count;
                decimal cresult = ccount / grade.Count;
                decimal dresult = dcount / grade.Count;
                decimal fresult = fcount / grade.Count;

                Console.WriteLine("Min in Grade in the list: " + min);
                Console.WriteLine("Max Grade in List: " + max);
                Console.WriteLine("Average of all Grades: " + Math.Round(avgresult) + "%");
                Console.WriteLine("Percentage of A's: " + Math.Round(aresult * 100, 2) + "%");
                Console.WriteLine("Percentage of B's: " + Math.Round(bresult * 100, 2) + "%");
                Console.WriteLine("Percentage of C's: " + Math.Round(cresult * 100, 2) + "%");
                Console.WriteLine("Percentage of D's: " + Math.Round(dresult * 100, 2) + "%");
                Console.WriteLine("Percentage of F's: " + Math.Round(fresult * 100, 2) + "%");


                Console.ReadKey();

                MainMenu();


            }

            void close()
            {
                Environment.Exit(0);
            }

            Console.ReadKey();
        }


    }
}