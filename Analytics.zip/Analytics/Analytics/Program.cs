﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analytics
{
    class Program
    {
        static void Main(string[] args)
        {
            List<decimal> numbers = new List<decimal>();


            numbers.Add(50.57m);
            numbers.Add(30.88m);
            numbers.Add(40.507m);
            numbers.Add(10.223m);
            numbers.Add(44.890m);
            numbers.Add(11.07m);
            numbers.Add(70.55m);
            numbers.Add(88.97m);
            numbers.Add(20.79m);
            numbers.Add(80.77m);

            decimal sum = 0;

            foreach (decimal M in numbers)
            {
                sum = sum + M;
                decimal result = sum / 10;
                Console.WriteLine("Average of list: " + result);

            }


            {
                var min = numbers.Min();
                Console.WriteLine("Minimum  value in List: " + min);
            }

            {
                var max = numbers.Max();

                Console.WriteLine("Maximum  value in List: " + max);
            }

            {
                Console.ReadKey();
            }

        }
    }


}
