﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1OOP
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Student> studentslist = new List<Student>();

            Student student1 = new Student("Fahad", "Yahya", 9);
            Student student2 = new Student("Moe", "Manshad", 10);
            Student student3 = new Student("Ali", "Ahmed", 5);

            studentslist.Add(student1);
            studentslist.Add(student2);
            studentslist.Add(student3);

            decimal total = 0;

            foreach (Student f in studentslist)
            {
                Console.WriteLine(f.FirstName+" "+f.LastName+"," + f.Grade);
                total += f.Grade;

            }

            total = total / studentslist.Count();
            //Console.WriteLine(total +  "  This is the Average ");

            {


                Console.ReadKey();



            }
        } }
}
