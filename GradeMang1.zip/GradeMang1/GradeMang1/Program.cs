﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeMang1
{
    class Program
    {
            static void Main(string[] args)
            {
                List<string> studentname = new List<string>();
                List<decimal> studentgrade = new List<decimal>();

                void menu()
                {
                    Console.Clear();

                    Console.WriteLine("1. Enter Student Name and Student Grade:");
                    Console.WriteLine("2. Display student grade average: ");
                    Console.WriteLine("3. Quit!");
                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1": student(); break;
                        case "2": average(); break;
                        case "3": quit(); break;
                    }
                    Console.ReadKey();
                }
                menu();


                void student()
                {
                    Console.Clear();

                    Console.WriteLine("Enter Students Name: ");
                    string first = Console.ReadLine();
                studentname.Add(first);

                    Console.WriteLine("Enter Students Grade: ");
                    decimal num = Convert.ToDecimal(Console.ReadLine());
                studentgrade.Add(num);

                    Console.WriteLine("List of Students: ");
                    for (int x = 0; x < studentname.Count; x++)
                    {
                        Console.Clear();


                        Console.WriteLine("Name: " + studentname[x] + " Grade: " + studentname[x]);
                    }
                    Console.ReadKey();


                    menu();

                }
                void average()
                {
                    decimal sum = 0;

                    foreach (decimal i in studentgrade)
                    {
                        sum = sum + i;
                    }
                    Console.Clear();


                    decimal result = sum / studentgrade.Count();
                    Console.WriteLine("The Average Grade is: " + result);

                    Console.ReadKey();
                    menu();

                }
                void quit()
                {
                    Environment.Exit(0);
                }
            }
        }
    }