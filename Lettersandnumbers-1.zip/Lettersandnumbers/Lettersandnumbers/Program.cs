﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lettersandnumbers
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Please type the word to be translated to numbers:   ");
            string letter = Console.ReadLine();

            int total = 0;


            foreach (int number in letter.ToUpper())
            {
                if (number == 'A')
                {
                    total = total + 0;
                }
                if (number == 'B')
                {
                    total = total + 1;
                }
                if (number == 'C')
                {
                    total = total + 1;
                }
                if (number == 'D')
                {
                    total = total + 2;
                }
                if (number == 'E')
                {
                    total = total + 3;
                }
                if (number == 'F')
                {
                    total = total + 5;
                }
                if (number == 'G')
                {
                    total = total + 8;
                }
                if (number == 'H')
                {
                    total = total + 13;
                }
                if (number == 'I')
                {
                    total = total + 21;
                }
                if (number == 'J')
                {
                    total = total + 34;
                }
                if (number == 'K')
                {
                    total = total + 55;
                }
                if (number == 'L')
                {
                    total = total + 89;
                }
                if (number == 'M')
                {
                    total = total + 144;
                }
                if (number == 'N')
                {
                    total = total + 233;
                }
                if (number == 'O')
                {
                    total = total + 377;
                }
                if (number == 'P')
                {
                    total = total + 610;
                }
                if (number == 'Q')
                {
                    total = total + 987;
                }
                if (number == 'R')
                {
                    total = total + 1597;
                }
                if (number == 'S')
                {
                    total = total + 2584;
                }
                if (number == 'T')
                {
                    total = total + 4181;
                }
                if (number == 'U')
                {
                    total = total + 6765;
                }
                if (number == 'V')
                {
                    total = total + 10946;
                }
                if (number == 'W')
                {
                    total = total + 17711;
                }
                if (number == 'X')
                {
                    total = total + 28657;
                }
                if (number == 'Y')
                {
                    total = total + 46368;
                }
                if (number == 'Z')
                {
                    total = total + 75025;
                }

            }

            Console.WriteLine(total);
            Console.ReadKey();

        }
    }
}
