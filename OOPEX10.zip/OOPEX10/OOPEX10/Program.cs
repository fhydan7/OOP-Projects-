﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX10
{
    class Program
    {
        public static Hotel MonHotel { get; set; }

        static void Main(string[] args)
        {
            Program.MonHotel = new Hotel("Monsters Inc");
            Menu();

            Console.WriteLine("\r\n" + "Press any key to terminate program...");
            Console.ReadKey();
        }

        public static void Menu()
        {
            while (true)
            {
                Console.WriteLine("Main Menu");
                Console.WriteLine("1) Show Monsters");
                Console.WriteLine("2) Show Reservations");
                Console.WriteLine("3) Book Reservation");
                Console.WriteLine("4) Exit Program" + "\r\n");

                Console.Write("Choose: ");
                string choice = Console.ReadLine();

                if (choice == "1")
                {
                    Console.Clear();
                    MonHotel.PrintMonster();
                }
                else if (choice == "2")
                {
                    Console.Clear();
                    MonHotel.PrintReserv();
                }
                else if (choice == "3")
                {
                    Console.Clear();
                    MonHotel.AddReserv();
                }
                else if (choice == "4")
                {
                    break;
                }
            }
        }
    }
}