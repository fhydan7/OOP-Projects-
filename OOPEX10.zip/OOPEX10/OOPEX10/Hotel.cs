﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX10
{
    class Hotel
    {
        public string Name { get; set; }

        public List<Monster> Monsters { get; set; }

        public List<Reservation> Reservations { get; set; }

        public Hotel(string name)
        {
            this.Name = name;

            this.Monsters = new List<Monster>()
            {
                new Monster("Ahmed", "Al", "Swamp Reek"),
                new Monster("Nasser", "Ma", "Mischief"),
                new Monster("Fahad", "Ya", "Claws of Death"),
                new Monster("Yahya", "Da", "Fire Breathing")
            };

            this.Reservations = new List<Reservation>()
            {
                new Reservation("Ahmed", "4/23/2020", "4/27/2020")
            };
        }

        public void AddReserv()
        {
            Console.WriteLine("Book Reservation");
            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("CheckIn Date (mm/dd/yyyy): ");
            string inDate = Console.ReadLine();

            Console.Write("CheckOut Date (mm/dd/yyyy): ");
            string outDate = Console.ReadLine();

            this.Reservations.Add(new Reservation(name, inDate, outDate));
            Console.WriteLine();
        }

        public void PrintMonster()
        {
            Console.WriteLine("Monsters");

            foreach (Monster monster in this.Monsters)
            {
                Console.Write("Name: ");
                Console.WriteLine(monster.Name);

                Console.Write("Type: ");
                Console.WriteLine(monster.Type);

                Console.Write("Ability: ");
                Console.WriteLine(monster.Ability + "\r\n");
            }
        }

        public void PrintReserv()
        {
            Console.WriteLine("Reservations");

            foreach (Reservation reserv in this.Reservations)
            {
                Console.Write("Name: ");
                Console.WriteLine(reserv.GetName());

                Console.Write("Check-In Date: ");
                Console.WriteLine(reserv.GetInDate());

                Console.Write("Check-Out: ");
                Console.WriteLine(reserv.GetOutDate() + "\r\n");
            }
        }
    }
}