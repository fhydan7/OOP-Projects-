﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX10
{
    class Monster : IAbility
    {
        public string Name { get; set; }

        public string Type { get; set; }

        public Monster(string name, string type, string ability)
        {
            this.Name = name;
            this.Type = type;
            this.Ability = ability;
        }
    }
}
