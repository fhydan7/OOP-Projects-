﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX10
{
    class Reservation
    {
        private string Name { get; set; }

        private string CheckInDate { get; set; }

        private string CheckOutDate { get; set; }

        public Reservation(string name, string checkIn, string checkOut)
        {
            this.Name = name;
            this.CheckInDate = checkIn;
            this.CheckOutDate = checkOut;
        }

        public string GetName()
        {
            return this.Name;
        }

        public string GetInDate()
        {
            return this.CheckInDate;
        }

        public string GetOutDate()
        {
            return this.CheckOutDate;
        }
    }
}
