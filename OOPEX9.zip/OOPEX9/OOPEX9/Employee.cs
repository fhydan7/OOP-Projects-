﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX9
{
    class Employee

    {

        public Employee(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }
        public int X { get; set; }
        public int Y { get; set; }


        public bool Getscore()

        {
            bool basket1 = false;
            bool basket2 = false;
            bool score = false;

            if (X == 1 && Y == 10)

            {
                basket1 = true;
                score = true;

            }

            if (X == 0 && Y == 10)

            {
                basket1 = true;
                score = true;
            }

            if (X == 1 && Y == 9)

            {
                basket1 = true;
                score = true;
            }
            if (X == -1 && Y == 10)

            {
                basket2 = true;
                score = true;
            }
            if (X == -1 && Y == 9)

            {
                basket2 = true;
                score = true;
            }

            if (X == 0 && Y == 10)

            {
                basket2 = true;
                score = true;
            }
            return score;



        }
    }



}
