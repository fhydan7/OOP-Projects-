﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX9
{
    class Court
    {

        public Court(List<Players> players)

        {
            this.players = players;

        }

        public List<Players> players { get; set; }


    }
}
