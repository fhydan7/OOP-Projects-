﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX9
{
    class Player : Employee
    {
        public Player(int x, int y) : base(x, y)
        {
            this.X = x;
            this.Y = y;
        }



    }
}
