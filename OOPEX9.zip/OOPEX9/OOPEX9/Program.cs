﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX9
{

    class Program
    {

        static void Main(string[] args)
        {

            List<Players> playerlist = new List<Players>();

            Players Naif = new Players("Team Red: Player  1", new Employee(0, 5));
            Players Moha = new Players("Team Red: Player  2", new Employee(0, 8));
            Players Ali = new Players("Team Red: Player  3", new Employee(4, 6));


            Players Fahad = new Players("Team Blue:Player  1", new Employee(5, 10));
            Players Ahmed = new Players("Team Blue:Player  2", new Employee(0, 10));
            Players Shahad = new Players("Team Blue:Player  3", new Employee(5, 7));

            Players referee = new Players("referee", new Employee(6, 4));
            Employee Basket = new Employee(-1, 10);
            Player football = new Player(-1, 10);
            Player soccer = new Player(1, 10);

            string sport = "basketball";

            playerlist.Add(Naif);
            playerlist.Add(Moha);
            playerlist.Add(Ali);
            playerlist.Add(Fahad);
            playerlist.Add(Ahmed);
            playerlist.Add(Shahad);

            Console.WriteLine("A game of:" + sport);

            List<string> distancelist = new List<string>();
            string distance = "";
            Console.WriteLine("Team List:" + "       " + "Position");

            foreach (Players p in playerlist)

            {

                Console.WriteLine(p.Team + ": " + p.Position.X + " " + p.Position.Y);
            }
            foreach (Players player in playerlist)

            {

                distance = Math.Sqrt(Math.Pow(player.Position.X - referee.Position.X, 2) + Math.Pow(player.Position.Y - referee.Position.Y, 2) * 1.0).ToString();


                distancelist.Add(distance);

            }
            distancelist.Sort();
            Console.WriteLine("Distance from referee");
            foreach (string dist in distancelist)

            {

                Console.WriteLine(Math.Round(Convert.ToDecimal(dist), 1));


            }
            if (Basket.Getscore() == true)

            {
                Console.WriteLine("A ball has been scored!");

            }
            else
            {
                Console.WriteLine("No ball has been scored, try again next time");
            }


            Console.ReadKey();
        }
    }
}
