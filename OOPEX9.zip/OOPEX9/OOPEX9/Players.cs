﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEX9
{
    class Players
    {
        public Players(string team, Employee position)

        {
            this.Team = team;
            this.Position = position;
        }
        public string Team { get; set; }
        public Employee Position { get; set; }


    }
}