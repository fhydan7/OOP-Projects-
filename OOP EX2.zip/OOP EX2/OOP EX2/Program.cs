﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_EX2
{
    class Program
    {
        static void Main(string[] args)
        {


            List<Student> sudentList = new List<Student>();

            Student myself = new Student("Fahad", "Yahya", 93);
            Student naif = new Student("Naif", "salad", 79);

            Student mark = new Student("mark", "Joe", 80);
            Student moe = new Student("Moe", "Manshad", 90);

            sudentList.Add(myself);
            sudentList.Add(naif);
            sudentList.Add(mark);
            sudentList.Add(moe);


            Course bacs200 = new Course(200, "bacs200", sudentList);
            Console.WriteLine("BACS200 Student ");

            bacs200.GetAverageGrade();
            bacs200.Getminimumgrade();
            bacs200.Getmaximumgrade();
            bacs200.GetPercentGrades();






            Console.ReadKey();
        }
    }
}
