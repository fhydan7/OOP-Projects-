﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_EX2
{
    class Course
    {


        public Course(int courseId, string name, List<Student> students)
        {
            this.CoursedId = courseId;
            this.CoureName = name;
            this.Studentslist = students;

        }
        public int CoursedId { get; set; }
        public List<Student> Studentslist { get; set; }

        public string CoureName { get; set; }



        public decimal GetAverageGrade()
        {

            decimal total = 0;


            foreach (Student x in Studentslist)
            {
                Console.WriteLine(x.FirstName + " " + x.LastName + " " + x.Grade);
                total += x.Grade;



            }


            total = total / Studentslist.Count;
            Console.WriteLine(total + " this is the avreg ");
            return 0;
        }

        public decimal Getminimumgrade()
        {
            decimal min = this.Studentslist[0].Grade;

            foreach (Student x in Studentslist)
            {



                if (x.Grade < min)
                    min = x.Grade;

            }

            Console.WriteLine("Minimum =" + min);
            return 0;
        }

        public decimal Getmaximumgrade()
        {
            decimal max = this.Studentslist[0].Grade;

            foreach (Student x in Studentslist)
            {



                if (x.Grade > max)
                    max = x.Grade;

            }

            Console.WriteLine("Maximum =" + max);

            return 0;

        }


        public decimal GetPercentGrades()
        {
            decimal a = 0;
            decimal b = 0;
            decimal c = 0;
            decimal d = 0;
            decimal f = 0;

            decimal precentage = this.Studentslist[0].Grade;

            {

                foreach (Student x in Studentslist)

                    if (x.Grade >= 90)
                    {
                        a = a + 1;
                    }

                    else if (x.Grade >= 80)
                    {
                        b = b + 1;
                    }

                    else if (x.Grade >= 70)
                    {
                        c = c + 1;
                    }

                    else if (x.Grade >= 60)
                    {
                        d = d + 1;
                    }

                    else if (x.Grade < 60)
                    {
                        f = f + 1;
                    }
                    else
                    {
                
                    }





                decimal aresult = a / Studentslist.Count;
                decimal bresult = b / Studentslist.Count;
                decimal cresult = c / Studentslist.Count;
                decimal dresult = d / Studentslist.Count;
                decimal fresult = f / Studentslist.Count;


                Console.WriteLine("Percentage of A : " + Math.Round(aresult * 100, 2) + "%");
                Console.WriteLine("Percentage of B : " + Math.Round(bresult * 100, 2) + "%");
                Console.WriteLine("Percentage of C : " + Math.Round(cresult * 100, 2) + "%");
                Console.WriteLine("Percentage of D : " + Math.Round(dresult * 100, 2) + "%");
                Console.WriteLine("Percentage of F : " + Math.Round(fresult * 100, 2) + "%");
            }
            return 0;
        }
    }
}
