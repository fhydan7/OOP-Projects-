﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX6OOP
{
    class Members
    { 
        public Members ( string membername, Account saving, Account checking)
        {

            this.Membername = membername;
            this.Saving = saving;
            this.Checking = checking;
        }

        public string Membername { get; set; }
        public Account Saving { get; set; }
        public Account Checking { get; set; }


    }
}
