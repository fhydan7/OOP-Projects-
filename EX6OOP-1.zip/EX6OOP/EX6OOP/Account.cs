﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX6OOP
{
    class Account
    {
        public Account( decimal balance, string type)

        {
            this.Balance = balance;
            this.Type = type;
        }

        public decimal Balance { get; set; }
        public string Type { get; set; }
    }
}
