﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllOOP
{
    class AdvanceCourses : Course
    {
        /* Inheritance:
           It is using Inheritance by Using the properties and methods from the 
           Parent class course. Only difference between an advancecourse is that
           it has an extra cost, but every other property is the same.
           Now there is no need to ReWrite all that code because a Advance course 
           is inhering the features from Course Class.                      
             */

        public List<Student> AdvanceStudents;
        private int ExtraCost { get; set; }

        public AdvanceCourses(int courseid, string coursename) : base(courseid, coursename)
        {
            AdvanceStudents = new List<Student>();

        }
        public AdvanceCourses(int extracost, int courseid, string coursename) : base(courseid, coursename)
        {
            this.ExtraCost = extracost;

        }


    }
}
