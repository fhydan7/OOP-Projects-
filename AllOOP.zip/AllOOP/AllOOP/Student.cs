﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllOOP
{
    class Student
    {
        /* Encapsulation:
         * By making the property Grade private, I am implementing encapsulation. Creating a 
           logical boundray to isolating the property to avoid any modification made by anybody
           who should notdo so. */

        public int Id { get; set; }
        public string Name { get; set; }
        private decimal Grade { get; set; }
        public Student(int id, string name, decimal grade)
        {
            this.Id = id;
            this.Name = name;
            this.Grade = grade;

        }

        /* Polymorphism:
         I am applying polomorphism by writting a second constructor that is 
         allowing the property Grade to have different implementation in our code.
         I wrote two methods with the same name to demonstrate this.
         */

        public Student(decimal grade)
        {
            this.Id = 1;
            this.Name = "";
            this.Grade = grade;
        }
        public int GetGrade(int x)
        {
            return x + Convert.ToInt32(this.Grade);
        }
        public decimal GetGrade()
        {
            return Grade;
        }

        public void SetGrade(decimal grade)
        {
            this.Grade = grade;
        }


    }
}