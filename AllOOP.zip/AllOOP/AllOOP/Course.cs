﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllOOP
{
    class Course
    {

        public string CourseName { get; set; }
        public int CourseID { get; set; }
        public List<Student> AllStudents;

        public Course(int courseid, string coursename)
        {
            this.CourseName = coursename;
            this.CourseID = courseid;
            AllStudents = new List<Student>();

        }

        public void AddStudent()
        {
            Console.WriteLine("Enter New Student ID: ");
            int NewID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter New Student Name: ");
            string Newname = Console.ReadLine();

            Student NewStudent = new Student(NewID, Newname, 0);
            AllStudents.Add(NewStudent);
            Console.Clear();
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("Course ID: " + CourseID + " |Course Name: " + CourseName);
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("List of Student in Course: " + CourseName);
            foreach (Student x in AllStudents)
            {
                Console.WriteLine("Name: " + x.Name + " |ID: " + x.Id);
            }

        }
        public void RemoveStudent()
        {
            foreach (Student x in AllStudents)
            {
                Console.WriteLine("Name: " + x.Name + " |ID: " + x.Id);
            }
            Console.WriteLine("Choose a Student to Remove");
            int ID = Convert.ToInt32(Console.ReadLine());

            foreach (Student x in AllStudents)
                if (ID == x.Id)
                {
                    AllStudents.Remove(x);
                }

        }
        public void EnterGrade()
        {
            Console.Clear();
            Console.WriteLine("List of students in Course: " + CourseName);
            foreach (Student x in AllStudents)
            {
                Console.WriteLine("Name: " + x.Name + " |ID: " + x.Id);
            }
            Console.WriteLine("Choose a Student to Enter Final Grade");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a Grade for the Student:");
            decimal NewGrade = Convert.ToDecimal(Console.ReadLine());

            foreach (Student x in AllStudents)
                if (ID == x.Id)
                {
                    x.SetGrade(NewGrade);
                    Console.WriteLine("ID: " + x.Id + " | Name: " + x.Name + " | Grade: " + NewGrade);

                }


        }
        public void RemoveCourse()
        {
            foreach (Student x in AllStudents)
            {

                this.AllStudents.Remove(x);
            }
        }
        public void Average()
        {
            decimal avg = 0;

            List<decimal> AllGrades = new List<decimal>();
            foreach (Student x in AllStudents)
            {
                AllGrades.Add(x.GetGrade());
            }
            foreach (decimal x in AllGrades)
            {
                if (x > 0)
                {
                    avg = avg + x;

                }
            }
            decimal total = avg / AllGrades.Count;

            Console.WriteLine("Student Average Grade: " + Math.Round(total));


        }
        public void Minimum()
        {
            decimal min = 0;
            string name = ("");

            List<decimal> AllGrades = new List<decimal>();
            foreach (Student x in AllStudents)
            {
                AllGrades.Add(x.GetGrade());

            }
            foreach (decimal x in AllGrades)
            {
                if (x > 0)
                {
                    min = AllGrades.Min();
                }
            }
            foreach (Student x in AllStudents)
            {
                if (x.GetGrade() == min)
                {
                    name = x.Name;
                }

            }
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("Minumum Grade: " + min + " Student: " + name);


        }
        public void Maximum()
        {
            decimal max = 0;
            string name = ("");
            List<decimal> AllGrades = new List<decimal>();
            foreach (Student x in AllStudents)
            {
                AllGrades.Add(x.GetGrade());
            }
            foreach (decimal x in AllGrades)
            {
                if (x > 0)
                {
                    max = AllGrades.Max();

                }
            }
            foreach (Student x in AllStudents)
            {
                if (x.GetGrade() == max)
                {
                    name = x.Name;
                }

            }
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("Maximum Grade: " + max + " Student: " + name);

        }
        public double Median()
        {
            List<decimal> AllGrades = new List<decimal>();
            foreach (Student x in AllStudents)
            {
                AllGrades.Add(x.GetGrade());
            }

            return Median();
        }
        public void Percentage()
        {
            double a = 0;
            double b = 0;
            double c = 0;
            double d = 0;
            double f = 0;
            List<decimal> AllGrades = new List<decimal>();
            foreach (Student x in AllStudents)
            {
                AllGrades.Add(x.GetGrade());
            }
            foreach (decimal x in AllGrades)
            {
                if (x >= 90)
                {
                    a = a + 1;
                }

                else if (x >= 80)
                {
                    b = b + 1;
                }

                else if (x >= 70)
                {
                    c = c + 1;
                }

                else if (x >= 60)
                {
                    d = d + 1;
                }

                else if (x < 60)
                {
                    f = f + 1;
                }
                else
                {

                }
            }


            double aresult = a / AllGrades.Count;
            double bresult = b / AllGrades.Count;
            double cresult = c / AllGrades.Count;
            double dresult = d / AllGrades.Count;
            double fresult = f / AllGrades.Count;

            Console.WriteLine("---------------------------------------");
            Console.WriteLine("Grade Percentage of All Enrolled students");
            Console.WriteLine("Percentage of A's: " + Math.Round(aresult * 100, 2) + "%");
            Console.WriteLine("Percentage of B's: " + Math.Round(bresult * 100, 2) + "%");
            Console.WriteLine("Percentage of C's: " + Math.Round(cresult * 100, 2) + "%");
            Console.WriteLine("Percentage of D's: " + Math.Round(dresult * 100, 2) + "%");
            Console.WriteLine("Percentage of F's: " + Math.Round(fresult * 100, 2) + "%");
        }

       
        public void CheckCourse()
        {
            int SelectCourses = Convert.ToInt32(Console.ReadLine());

            if (SelectCourses == this.CourseID)
            {

            }
        }



    }
}