﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllOOP
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Encapsulation is being implemented in Student Class, More comments in there.
             *Inheritance is being implemented in AdvanceCourses Class, more comments in there.
             *Polymorphism in being implemented in Student Class, more comments in there.
             * */

            List<Course> AllCourses = new List<Course>();

            TeacherMenu();
            void TeacherMenu()
            {
                Console.Clear();
                Console.WriteLine("Teacher Interface");
                Console.WriteLine("----------------------------------------");
                Console.WriteLine("Choose one of the following options:");
                Console.WriteLine("1. Enter Course");
                Console.WriteLine("2. Student Menu(Add Students)");
                Console.WriteLine("3. Remove Course");
                Console.WriteLine("4. Print All Courses");
                Console.WriteLine("5. Close Interface");
                Console.WriteLine("----------------------------------------");

                string usersChoice = Console.ReadLine();
                switch (usersChoice)
                {
                    case "1":
                        EnterCourse();
                        break;
                    case "2":
                        StudentMenu();
                        break;
                    case "3":
                        RemoveCourse();
                        break;
                    case "4":
                        PrintCourses();
                        break;
                    case "5":
                        close();
                        break;
                }

            }
            void PrintCourses()
            {
                Console.WriteLine("----------------------------------------");
                Console.WriteLine("All Courses");
                foreach (Course x in AllCourses)
                {
                    Console.WriteLine("Course ID: " + x.CourseID + " |Course Name: " + x.CourseName);
                }
                Console.ReadKey();
                TeacherMenu();
            }
            void StudentMenu()
            {
                Console.Clear();
                Console.WriteLine("Student Menu Interface");
                Console.WriteLine("----------------------------------------");
                Console.WriteLine("Choose one of the following options:");
                Console.WriteLine("1. Enter Student");
                Console.WriteLine("2. Remove Student");
                Console.WriteLine("3. Enter Grade");
                Console.WriteLine("4. Grade Analytics");
                Console.WriteLine("5. Close Interface");
                Console.WriteLine("----------------------------------------");
                string usersChoice = Console.ReadLine();
                switch (usersChoice)
                {
                    case "1":
                        EnterStudent();
                        break;
                    case "2":
                        RemoveStudent();
                        break;
                    case "3":
                        EnterGrade();
                        break;
                    case "4":
                        GradeAnalytics();
                        break;
                    case "5":
                        close();
                        break;
                }
            }
            void EnterStudent()
            {
                Console.Clear();
                foreach (Course x in AllCourses)
                {
                    Console.WriteLine("Course ID: " + x.CourseID + " |Course Name: " + x.CourseName);
                }
                Console.WriteLine("Select a Course to Add a Student: ");
                int SelectCourses;
                SelectCourses = Convert.ToInt32(Console.ReadLine());

                bool exist = false;
                foreach (Course x in AllCourses)
                    if (SelectCourses == x.CourseID)
                    {
                        x.AddStudent();
                        exist = true;
                    }
                if (exist == false)
                {
                    Console.WriteLine("Course does not exist");
                }
                TeacherMenu();
            }
            void EnterCourse()
            {
                Console.Clear();
                Console.WriteLine("----------------------------------------");
                Console.WriteLine("Enter a New Course ID: ");
                int NewID = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter a Name for the Course:");
                string Newname = Console.ReadLine();

                Console.WriteLine("New Course: " + Newname + "| ID: " + NewID + "| Has been Succesfully Created!");

                Course NewCourse = new Course(NewID, Newname);

                AllCourses.Add(NewCourse);
                Console.ReadKey();
                TeacherMenu();

            }
            void RemoveCourse()
            {
                Console.Clear();
                Console.WriteLine("----------------------------------------");
                foreach (Course x in AllCourses)
                {
                    Console.WriteLine("Course ID: " + x.CourseID + " |Course Name: " + x.CourseName);
                }
                Console.WriteLine("Select Course ID to Remove Course and its Students");
                int SelectCourses;
                SelectCourses = Convert.ToInt32(Console.ReadLine());

                bool exist = false;
                foreach (Course x in AllCourses)
                    if (SelectCourses == x.CourseID)
                    {
                        x.RemoveCourse();
                        AllCourses.Remove(x);
                        exist = true;
                    }
                if (exist == false)
                {
                    Console.WriteLine("Course does not exist");
                }
                Console.ReadKey();
                TeacherMenu();
            }
            void RemoveStudent()
            {
                Console.Clear();
                Console.WriteLine("----------------------------------------");
                foreach (Course x in AllCourses)
                {
                    Console.WriteLine("Course ID: " + x.CourseID + " |Course Name: " + x.CourseName);
                }
                int SelectCourses;
                SelectCourses = Convert.ToInt32(Console.ReadLine());

                bool exist = false;
                foreach (Course x in AllCourses)
                    if (SelectCourses == x.CourseID)
                    {
                        x.RemoveStudent();
                        exist = true;
                    }
                if (exist == false)
                {
                    Console.WriteLine("Course does not exist");
                }
                Console.ReadKey();
                TeacherMenu();
            }
            void EnterGrade()
            {
                Console.Clear();
                Console.WriteLine("----------------------------------------");
                foreach (Course x in AllCourses)
                {
                    Console.WriteLine("Course ID: " + x.CourseID + " |Course Name: " + x.CourseName);
                }
                Console.WriteLine("Choose a Course to Edit a Student Grade");
                int SelectCourses;
                SelectCourses = Convert.ToInt32(Console.ReadLine());
                bool exist = false;
                foreach (Course x in AllCourses)
                    if (SelectCourses == x.CourseID)
                    {
                        x.EnterGrade();
                        exist = true;
                    }
                if (exist == false)
                {
                    Console.WriteLine("Course does not exist");
                }
                Console.ReadKey();
                TeacherMenu();
            }
            void GradeAnalytics()
            {
                Console.Clear();
                Console.WriteLine("Grade Analytics");
                Console.WriteLine("----------------------------------");
                foreach (Course x in AllCourses)
                {
                    Console.WriteLine("Course ID: " + x.CourseID + " |Course Name: " + x.CourseName);
                }
                Console.WriteLine("Choose a Course to Print Grade Analytics");
                int SelectCourses;
                SelectCourses = Convert.ToInt32(Console.ReadLine());
                bool exist = false;
                foreach (Course x in AllCourses)
                    if (SelectCourses == x.CourseID)
                    {
                        x.Average();
                        x.Minimum();
                        x.Maximum();
                        x.Percentage();
                        exist = true;
                    }
                if (exist == false)
                {
                    Console.WriteLine("Course does not exist");
                }
                Console.ReadKey();
                TeacherMenu();

            }
            void close()
            {
                Environment.Exit(0);
            }
            Console.Read();
        }
    }
}
