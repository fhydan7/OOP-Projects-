﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List_Print
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> names = new List<string>();

            names.Add("Fahad");
            names.Add("Ali");
            names.Add("Muhanad");
            names.Add("Yahya");
            names.Add("Sara");
            names.Add("Zahra");
            names.Add("Naif");
            names.Add("Ahmed");
            names.Add("Ayman");
            names.Add("khlied");


            //names.Sort();
            //names.Reverse();




            foreach(string x in names)
            {
                Console.WriteLine(x);
            }
           


            
            {
                Console.WriteLine("Please Enter the name you want to be deleted from this list: ");
                string erase = Console.ReadLine();

                foreach (char F in erase)
                {
                    names.Remove(erase);

                }
                Console.Clear();
                Console.WriteLine("New List: ");
                for (int x = 0; x < names.Count; x++)
                {
                    Console.WriteLine(names[x]);

                }
               



            }
            Console.ReadKey();
               
        }
    }

}